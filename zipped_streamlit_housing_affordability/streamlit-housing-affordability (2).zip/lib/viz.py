import plotly.express as px
import pandas as pd

def line_cpi(cpi_wide: pd.DataFrame):
    cols = [c for c in cpi_wide.columns if c != 'date']
    fig = px.line(cpi_wide, x='date', y=cols, title="CPI Series Over Time")
    fig.update_layout(legend_title_text="Series ID")
    return fig

def line_prices(redfin_yearly: pd.DataFrame, county_meta: pd.DataFrame, county_fips: str):
    sub = redfin_yearly[redfin_yearly['county_fips']==county_fips]
    name = county_meta[county_meta['county_fips']==county_fips].iloc[0]['county_name']
    fig = px.line(sub, x='year', y='avg_price', markers=True, title=f"Average Median Sale Price per Year — {name}")
    return fig

def line_ratio(ratio_df: pd.DataFrame, county_meta: pd.DataFrame, county_fips: str):
    sub = ratio_df[ratio_df['county_fips']==county_fips]
    name = county_meta[county_meta['county_fips']==county_fips].iloc[0]['county_name']
    fig = px.line(sub, x='year', y='price_to_income', markers=True, title=f"Price-to-Income Ratio — {name}")
    return fig

def choropleth_ratio(ratio_df: pd.DataFrame, counties: pd.DataFrame, year: int):
    # Plotly county choropleth expects 5-digit FIPS in 'fips'
    df = ratio_df[ratio_df['year']==year].merge(counties[['county_fips','county_name','state']], on='county_fips', how='left').rename(columns={'county_fips':'fips'})
    fig = px.choropleth(df, geojson="https://raw.githubusercontent.com/plotly/datasets/master/geojson-counties-fips.json",
                        locations='fips', color='price_to_income',
                        hover_name='county_name', hover_data={'fips':False,'state':True,'price_to_income':':.2f'},
                        scope="usa", title=f"Price-to-Income Ratio by County — {year}")
    fig.update_geos(fitbounds="locations", visible=False)
    return fig
