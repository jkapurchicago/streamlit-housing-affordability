import os
import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")

@st.cache_data(show_spinner=False)
def read_csv(name: str) -> pd.DataFrame:
    path = os.path.join(DATA_DIR, name)
    return pd.read_csv(path)

def secrets_has_mysql() -> bool:
    try:
        s = st.secrets["mysql"]
        return all(k in s for k in ("host","user","password","database"))
    except Exception:
        return False

def get_mysql_engine():
    s = st.secrets["mysql"]
    url = f"mysql+pymysql://{s['user']}:{s['password']}@{s['host']}:{s.get('port',3306)}/{s['database']}"
    return create_engine(url, pool_pre_ping=True)

@st.cache_data(show_spinner=True, ttl=300)
def load_data(source: str = "auto"):
    """Return dict of dataframes: acs, redfin, cpi, counties.

    source: 'auto' | 'mysql' | 'csv'
    - auto: use MySQL if configured, else CSV
    """
    if source == "auto":
        source = "mysql" if secrets_has_mysql() else "csv"

    if source == "mysql":
        engine = get_mysql_engine()
        with engine.begin() as conn:
            acs = pd.read_sql(text("SELECT county_fips, county_name, state, year, income_usd FROM fact_income"), conn)
            redfin = pd.read_sql(text("""
                SELECT county_fips, county_name, state, period, median_sale_price
                FROM fact_housing
            """), conn)
            cpi = pd.read_sql(text("""
                SELECT DATE_FORMAT(date_key,'%Y-%m') AS date, series_id, value
                FROM fact_cpi
            """), conn)
            counties = pd.read_sql(text("""
                SELECT county_fips, county_name, state, state_fips FROM dim_location WHERE county_fips IS NOT NULL
            """), conn)
        return {"acs": acs, "redfin": redfin, "cpi": cpi, "counties": counties}
    else:
        acs = read_csv("acs_income_sample.csv")
        redfin = read_csv("redfin_housing_sample.csv")
        cpi = read_csv("bls_cpi_sample.csv")
        counties = read_csv("county_fips_sample.csv")
        return {"acs": acs, "redfin": redfin, "cpi": cpi, "counties": counties}

def compute_price_to_income(acs: pd.DataFrame, redfin: pd.DataFrame) -> pd.DataFrame:
    """Yearly price-to-income ratio by county (median sale price avg over year / income)."""
    redfin['year'] = redfin['period'].str.slice(0,4).astype(int)
    yearly = redfin.groupby(['county_fips','year'], as_index=False)['median_sale_price'].mean().rename(columns={'median_sale_price':'avg_price'})
    df = yearly.merge(acs[['county_fips','year','income_usd']], on=['county_fips','year'], how='left')
    df['price_to_income'] = (df['avg_price'] / df['income_usd']).round(2)
    return df

def cpi_pivot(cpi: pd.DataFrame) -> pd.DataFrame:
    wide = cpi.pivot_table(index='date', columns='series_id', values='value').reset_index()
    return wide
