import streamlit as st
import pandas as pd
from lib.data_loader import load_data, compute_price_to_income, cpi_pivot
from lib.viz import line_cpi, choropleth_ratio
from datetime import datetime

st.set_page_config(page_title="Housing Affordability — CPI vs Income vs Home Prices", layout="wide")

st.title("🏡 Housing Affordability — CPI vs Income vs Home Prices")
st.caption("A portfolio app comparing housing costs (Redfin), incomes (ACS), and inflation (BLS CPI).")

with st.sidebar:
    st.header("Data Source")
    source = st.radio("Use data from:", ["auto","csv","mysql"], index=0, help="auto picks MySQL if configured in secrets, else CSV samples")
    st.markdown("---")
    st.subheader("About Keys")
    st.write("Optionally add `BLS_KEY`, `CENSUS_KEY`, and `[mysql]` credentials to `.streamlit/secrets.toml`.")
    st.markdown("---")
    st.write("Built with ❤️ for CS394: Data Engineering")

data = load_data(source)
acs, redfin, cpi, counties = data["acs"], data["redfin"], data["cpi"], data["counties"]

ratio_df = compute_price_to_income(acs, redfin)
cpi_wide = cpi_pivot(cpi)

# KPIs
latest_year = int(ratio_df["year"].max())
latest = ratio_df[ratio_df["year"]==latest_year]
kpi_avg_ratio = latest["price_to_income"].mean()
kpi_median_price = redfin[redfin["period"].str.startswith(str(latest_year))]["median_sale_price"].median()
kpi_income = acs[acs["year"]==latest_year]["income_usd"].median()

c1,c2,c3 = st.columns(3)
c1.metric("Avg Price-to-Income (counties)", f"{kpi_avg_ratio:.2f}", help="Average over shown counties for the latest year")
c2.metric("Median Sale Price (latest year, median of months)", f"${int(kpi_median_price):,}")
c3.metric("Median Household Income (latest year)", f"${int(kpi_income):,}")

st.subheader("Inflation Context — CPI Series")
st.plotly_chart(line_cpi(cpi_wide), use_container_width=True)

st.subheader("Affordability Map — Price-to-Income Ratio by County")
selected_year = st.slider("Year", int(ratio_df["year"].min()), int(ratio_df["year"].max()), value=latest_year, step=1)
st.plotly_chart(choropleth_ratio(ratio_df, counties, selected_year), use_container_width=True)

st.markdown("---")
st.markdown("### How we compute price-to-income")
st.code("""
# 1) Aggregate Redfin monthly prices to yearly average per county
redfin['year'] = redfin['period'].str.slice(0,4).astype(int)
yearly = redfin.groupby(['county_fips','year'], as_index=False)['median_sale_price'].mean()

# 2) Join to ACS income by county/year
df = yearly.merge(acs[['county_fips','year','income_usd']], on=['county_fips','year'], how='left')

# 3) Ratio = avg_price / income_usd
df['price_to_income'] = (df['median_sale_price'] / df['income_usd']).round(2)
""", language="python")
